# httimple.rs [![Build Status](https://travis-ci.org/halvorboe/httimple.rs.svg?branch=master)](https://travis-ci.org/halvorboe/httimple.rs)
Simple HTTP 2.0 library for building APIs



Libraries:
rustls -> To get tls in rust 

### JAM

After AWS S3 became a thing, hosting files on a website is not as useful as before. Httimple wants to make this simple by offering a simple, json only api to talk to front-end code.
